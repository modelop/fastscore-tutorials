# FastScore GBM demo

This package contains an implementation of a GBM in both Python and R, as well
as the necessary data to train and run the GBM in FastScore.

## Setting up FastScore

Start FastScore and Kafka using Docker-Compose with:
```
docker-compose -f kafka-compose up -d
docker-compose up -d
```
Configure FastScore with the CLI:
```
fastscore connect https://localhost:8000
fastscore config set config.yml
fastscore fleet
```

## Loading the model

Load the model with
```
fastscore model add gbm score_auto_gbm.py
fastscore attachment upload gbm score_auto_gbm.tar.gz
```
Load the stream descriptors and schemata with
```
fastscore stream add gbm_in sd_input.json
fastscore stream add gbm_out sd_output.json
fastscore schema add gbm_input gbm_input.avsc
fastscore schema add gbm_output gbm_output.avsc
```
The model is now ready to run.

## Running the model

Run the model with
```
fastscore model run gbm gbm_in gbm_out
```
You can now deliver inputs to the model over Kafka in the topic "input"; the
scores are returned on the Kafka topic "output".

To do this with the included Kafka utility (kafkaesq):
```
./kafkaesq --input-file gbm_input_data_multiline.json input output
```
will send each line in the input file, and print the response. Or, you can do
```
./kafkaesq input output
```
to manually enter the scores.
