library(caret)
library(gbm)
library(jsonlite)

# read in auto risk data
autoDF <- read.csv("https://archive.ics.uci.edu/ml/machine-learning-databases/autos/imports-85.data",
                   header = FALSE, 
                   na.strings = "?")
colNames <- c("risk", 
              "normalizedLosses", 
              "make", "fuelType", 
              "aspiration", 
              "numDoors", 
              "bodyStyle", 
              "driveWheels", 
              "engineLocation", 
              "wheelBase", 
              "length", 
              "width", 
              "height", 
              "curbWeight",
              "engineType",
              "numCylinders",
              "engineSize",
              "fuelSystem",
              "bore",
              "stroke",
              "compressionRatio",
              "horsepower",
              "peakRPM",
              "cityMPG",
              "highwayMPG",
              "price")
colnames(autoDF) <- colNames

# transform risk variable to factor
#autoDF$risk = as.factor(autoDF$risk)
#levels(autoDF$risk) <- c("Risk-2", "Risk-1", "Risk0", "Risk1", "Risk2", "Risk3")

# set outcome and feature variables
outcomeName <- "risk"
predictorsNames <- names(autoDF)[names(autoDF) != outcomeName & names(autoDF) != "normalizedLosses"]

# split data into training and test sets
set.seed(1234)
splitIndex <- createDataPartition(autoDF[,outcomeName], p = .75, list = FALSE, times = 1)
trainDF <- autoDF[ splitIndex,]
testDF  <- autoDF[-splitIndex,]

# train GBM model
fitControl <- trainControl(method = "cv",
                           number = 5,
                           verboseIter = FALSE)
set.seed(1234)
gbmFit <- train(trainDF[,predictorsNames],
                trainDF[,outcomeName],
                method = "gbm",
                trControl = fitControl,
                preProc = c("center", "scale"))
print(gbmFit)
save(gbmFit, file = "/Users/z-cankova/Demos/GBM_risk/gbmFit.RData")
pretty.gbm.tree(gbmFit$finalModel, i.tree = 1)

# check accuracy on test set and save test set as json
predictions <- predict(object = gbmFit, testDF[,predictorsNames], type = "raw")
print(postResample(pred = predictions, obs = testDF[,outcomeName]))
testJson <- toJSON(testDF[names(testDF) != "risk" & names(testDF) != "normalizedLosses"], na = "null", digits = 10)
write(testJson, file = "/Users/z-cankova/Demos/GBM_risk/gbm_input_data.json")

# save tree as json (use Shane's gbm tree converter)
# source("gbmTreeJson.R")
# jsonGbmTree <- wrapTree2(gbmFit$finalModel, TRUE, "gbmTree.json")