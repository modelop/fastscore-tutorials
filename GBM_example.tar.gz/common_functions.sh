#!/bin/bash
# functions that can be shared by multiple scripts
# include in your bash script with "source common_functions.sh"

# how long to wait before a command times out
timelimit=60

# echos the command entered, and whether it returned a nonzero return code (failed)
function test_cmd {
  start_time="$(date +%s%3N)"
  timeout $timelimit "$@"
  rcode=$?
  end_time="$(date +%s%3N)"
  time_to_complete=$((end_time - start_time))
  printf "%s " "$@ :"
  if [ "$rcode" == "0" ]; then printf "${GREEN}OK${NC} (${time_to_complete} ms)\n"
  else
    if [ "$rcode" == "124" ]; then printf "${RED}FAIL! (timed out)${NC}\n"
    else
      printf "${RED}FAIL!${NC}\n"
    fi
    RETURNCODE=1
  fi
}
