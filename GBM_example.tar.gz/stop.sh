#!/bin/bash

RETURNCODE=0
RED='\033[0;31m'
GREEN='\033[0;32m'
NC='\033[0m' # No Color

# clean up
printf "Tests complete, cleaning up...\n"
docker-compose -f docker-compose.yml down -v 
docker-compose -f kafka-compose.yml down -v

exit 0
