#!/bin/bash
# test a simple model using FastScoreCLI

RETURNCODE=0
RED='\033[0;31m'
GREEN='\033[0;32m'
NC='\033[0m' # No Color

source common_functions.sh
printf "Running a Python GBM model with FastScoreCLI\n"

test_cmd fastscore job run GBM GBM-in GBM-out
timeout 180 python kafka_client.py data/gbm_input_data_multiline.json input output -v
test_cmd fastscore job stop

exit $RETURNCODE
