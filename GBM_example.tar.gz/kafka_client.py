#!bin/bash/py

from kafka import KafkaProducer, KafkaConsumer, TopicPartition
import argparse
import json
import os
import sys
import time

def main():
    desc = 'A command line utility to stream a file over Kafka and then report the output.'
    parser = argparse.ArgumentParser(description=desc)
    parser.add_argument('input', type=str, help='The input data file.')
    parser.add_argument('input_topic', type=str, help='Topic to send input on')
    parser.add_argument('output_topic', type=str, help='Topic to receive output on')
    parser.add_argument('-v', '--verbose', action='store_true',
        help='Display some additional output.')
    parser.add_argument('-vv', '--veryverbose', action='store_true',
        help='Display lots of additional output (mostly for debugging).')
    parser.add_argument('-neos', '--no_end_of_stream', help='Don\'t send $end-of-stream at the end of the stream',
        action='store_true')
    args = parser.parse_args()

    producer = KafkaProducer()
    consumer = KafkaConsumer(args.output_topic)

    # Send our data
    messages_sent = 0
    messages_received = 0
    start_of_stream = '$start-of-stream' + str(time.time())
    producer.send(args.output_topic, start_of_stream) # let the consumer know we've started
    with open(args.input, 'r') as f:
        for line in f:
            producer.send(args.input_topic, line.strip())
            messages_sent += 1
            time.sleep(0)
    if not args.no_end_of_stream:
        producer.send(args.input_topic, '$end-of-stream')
    if args.verbose or args.veryverbose:
        print "Sent " + str(messages_sent) + " messages."
    stream_started = False
    for message in consumer:
        if args.veryverbose:
            print "%s:%d:%d count=%d val=%s" % (message.topic, message.partition, message.offset, messages_received, message.value)
        if message.value == start_of_stream:
            stream_started = True
            continue
        if message.offset == 1:
            stream_started = True
        if not stream_started:
            continue
        if not args.veryverbose:
            print message.value
        messages_received += 1
        if messages_received == messages_sent:
            break
    consumer.commit()
    consumer.close()

    if args.verbose:
        print ' ---------- '
        print 'Messages sent: ' + str(messages_sent)
        print 'Messages received: ' + str(messages_received)

    return 0

if __name__ == "__main__":
    main()
