#!/bin/bash
# start up FastScore and Kafka.

# Kafka startup
docker-compose -f kafka-compose.yml up -d

# FastScore container startup
docker-compose up -d

echo "Installing Pandas and Scikit-Learn"
# Install Scikit-Learn and Pandas in the container
docker-compose exec engine-1 pip install pandas
docker-compose exec engine-1 pip install scikit-learn

docker-compose exec engine-1 bash -c 'echo pandas >> /root/engine/lib/engine-1.3/priv/runners/python/python.modules'
docker-compose exec engine-1 bash -c 'echo sklearn >> /root/engine/lib/engine-1.3/priv/runners/python/python.modules'

# Connect to and Configure FastScore
echo "Connecting to FastScore"
fastscore connect https://localhost:8000
echo "Attempting to configure FastScore..."
fastscore config set config.yml

echo "FastScore Health Check:"
fastscore fleet