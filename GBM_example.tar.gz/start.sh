#!/bin/bash

RETURNCODE=0
RED='\033[0;31m'
GREEN='\033[0;32m'
NC='\033[0m' # No Color

# Start with Docker-Compose
printf "Startup with Docker-Compose\n"
printf "Starting Kafka \n"
docker-compose -f kafka-compose.yml up -d
if [ "$?" != "0" ];
then
  printf "${RED}FAIL: ${NC}docker-compose -f kafka-compose.yml up -d\n"
  exit 1
fi
sleep 10
printf "Starting FastScore \n"
docker-compose up -d
if [ "$?" != "0" ];
then
  printf "${RED}FAIL: ${NC}docker-compose up -d\n"
  exit 1
fi
printf "Installing missing packages (pandas and sklearn)\n"
docker-compose exec engine-1 pip install pandas
docker-compose exec engine-1 pip install sklearn
docker-compose exec engine-1 bash -c 'echo pandas >> /root/engine/lib/engine-1.3/priv/runners/python/python.modules'
docker-compose exec engine-1 bash -c 'echo sklearn.ensemble >> /root/engine/lib/engine-1.3/priv/runners/python/python.modules'
docker-compose exec engine-1 bash -c 'echo sklearn.pipeline >> /root/engine/lib/engine-1.3/priv/runners/python/python.modules'

printf "(waiting for setup to complete)\n"
sleep 15 # wait for things to get set up

fastscore connect https://localhost:8000
fastscore config set config.yml
sleep 5
fastscore fleet
printf "Adding models and stream descriptors \n"
test_cmd fastscore stream add GBM-in gbm-in.json
test_cmd fastscore stream add GBM-out gbm-out.json
test_cmd fastscore model add GBM score_auto_gbm.py
test_cmd fastscore attachment upload GBM gbm.tar.gz

exit 0
